<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;

if (!defined('ABSPATH')) exit;

class Breadcrumbs_Widget extends Widget_Base {

    public function get_name() {
        return 'breadcrumbs_custom';
    }

    public function get_title() {
        return 'Breadcrumbs Custom';
    }

    public function get_icon() {
        return 'eicon-folder';
    }

    public function get_categories() {
        return ['general'];
    }

    public function _register_controls() {
        $this->start_controls_section('content_section', [
            'label' => 'Conteúdo'
        ]);

        $this->add_control('separator', [
            'label' => 'Separador',
            'type' => Controls_Manager::TEXT,
            'default' => '&raquo;',
        ]);

        $this->add_control('icon_home', [
            'label' => 'Icone da Home',
            'type' => Controls_Manager::ICONS,
            'default' => [
                'value' => 'fas fa-home',
                'library' => 'fa-solid',
            ],
        ]);

        $this->add_control('use_schema', [
            'label' => 'Usar Schema Markup?',
            'type' => Controls_Manager::SWITCHER,
            'default' => 'yes',
        ]);

        $this->end_controls_section();

        $this->start_controls_section('style_section', [
            'label' => 'Estilo',
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_control('color_text', [
            'label' => 'Cor do Texto',
            'type' => Controls_Manager::COLOR,
            'default' => '#333',
            'selectors' => [
                '{{WRAPPER}} .breadcrumbs' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_control('color_icon', [
            'label' => 'Cor do Ícone da Home',
            'type' => Controls_Manager::COLOR,
            'default' => '#0073aa',
            'selectors' => [
                '{{WRAPPER}} .breadcrumbs .home-icon' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'typography',
            'selector' => '{{WRAPPER}} .breadcrumbs',
        ]);

        $this->end_controls_section();
    }

    public function render() {
        $settings = $this->get_settings_for_display();
        echo $this->generate_breadcrumbs(
            $settings['separator'],
            $settings['icon_home'],
            $settings['use_schema'] === 'yes'
        );
    }

    private function generate_breadcrumbs($separator, $icon_home, $use_schema) {
        global $post;

        $position = 1;
        $output = '<nav class="breadcrumbs" ' . ($use_schema ? 'itemscope itemtype="https://schema.org/BreadcrumbList"' : '') . '>';

        $output .= $this->item($position++, get_home_url(), 'Início', $icon_home, $use_schema);

        if (is_category() || is_single()) {
            $category = get_the_category();
            if (!empty($category)) {
                $output .= $separator . $this->item($position++, get_category_link($category[0]->term_id), $category[0]->cat_name, '', $use_schema);
            }
            if (is_single()) {
                $output .= $separator . $this->item($position++, '', get_the_title(), '', $use_schema, true);
            }
        } elseif (is_page() && $post->post_parent) {
            $parent_id = $post->post_parent;
            $crumbs = [];
            while ($parent_id) {
                $page = get_page($parent_id);
                $crumbs[] = $this->item($position++, get_permalink($page->ID), get_the_title($page->ID), '', $use_schema);
                $parent_id = $page->post_parent;
            }
            $crumbs = array_reverse($crumbs);
            $output .= $separator . implode($separator, $crumbs);
            $output .= $separator . $this->item($position++, '', get_the_title(), '', $use_schema, true);
        } elseif (is_page()) {
            $output .= $separator . $this->item($position++, '', get_the_title(), '', $use_schema, true);
        } elseif (is_search()) {
            $output .= $separator . $this->item($position++, '', 'Busca por: "' . get_search_query() . '"', '', $use_schema, true);
        } elseif (is_404()) {
            $output .= $separator . $this->item($position++, '', 'Erro 404', '', $use_schema, true);
        }

        $output .= '</nav>';
        return $output;
    }

    private function item($pos, $url, $label, $icon, $schema, $is_last = false) {
        $icon_html = '';
        if (!empty($icon['value'])) {
            ob_start();
            Icons_Manager::render_icon($icon, ['aria-hidden' => 'true', 'class' => 'home-icon']);
            $icon_html = ob_get_clean() . ' ';
        }

        if ($schema) {
            $item = '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
            if (!$is_last && $url) {
                $item .= '<a href="' . esc_url($url) . '" itemprop="item">' . $icon_html . '<span itemprop="name">' . esc_html($label) . '</span></a>';
            } else {
                $item .= '<span itemprop="name">' . $icon_html . esc_html($label) . '</span>';
            }
            $item .= '<meta itemprop="position" content="' . $pos . '" /></span>';
        } else {
            if (!$is_last && $url) {
                $item = '<a href="' . esc_url($url) . '">' . $icon_html . esc_html($label) . '</a>';
            } else {
                $item = '<span>' . $icon_html . esc_html($label) . '</span>';
            }
        }
        return $item;
    }
}
